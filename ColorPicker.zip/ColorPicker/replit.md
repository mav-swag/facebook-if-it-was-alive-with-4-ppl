# Facebook Clone Application

## Overview

This is a full-stack Facebook clone application built with React, Express.js, Drizzle ORM, and PostgreSQL. The application provides a social media platform where users can create posts, like content, and view friend suggestions. It uses a modern tech stack with TypeScript throughout and includes a comprehensive UI component library.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a monorepo structure with clear separation between client and server code:

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight routing library)
- **State Management**: TanStack Query (React Query) for server state management
- **UI Framework**: Tailwind CSS with shadcn/ui component library
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Session Management**: PostgreSQL-based sessions with connect-pg-simple

### Data Storage Strategy
- **Primary Database**: PostgreSQL for all application data
- **ORM**: Drizzle ORM for type-safe database operations
- **Migration Strategy**: Drizzle Kit for schema migrations
- **In-Memory Fallback**: MemStorage class for development/testing without database

## Key Components

### Database Schema
Located in `shared/schema.ts`, defines three main entities:
- **Users**: Authentication and profile information
- **Posts**: Social media posts with content, images, likes, and comments
- **Friend Suggestions**: Recommended connections with mutual friend counts

### API Endpoints
- `GET /api/posts` - Retrieve all posts with author information
- `POST /api/posts` - Create new posts
- `POST /api/posts/:id/like` - Like/unlike posts
- `GET /api/friend-suggestions` - Get friend recommendations

### Frontend Pages
- **Home Page**: Main social media feed with post creation and friend suggestions
- **404 Page**: Error handling for undefined routes

### UI Component System
- Comprehensive shadcn/ui component library
- Consistent design system with CSS variables
- Responsive design with mobile-first approach
- Dark mode support built into the design tokens

## Data Flow

1. **Client Requests**: Frontend makes API calls using TanStack Query
2. **Server Processing**: Express.js routes handle business logic
3. **Database Operations**: Drizzle ORM manages PostgreSQL interactions
4. **Response Handling**: JSON responses with proper error handling
5. **State Updates**: React Query automatically updates UI state

## External Dependencies

### Production Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL driver
- **@tanstack/react-query**: Server state management
- **drizzle-orm**: Type-safe database ORM
- **express**: Web application framework
- **react**: UI library
- **tailwindcss**: Utility-first CSS framework

### Development Tools
- **Vite**: Build tool and development server
- **TypeScript**: Type safety and developer experience
- **Drizzle Kit**: Database migration tool
- **ESBuild**: Fast JavaScript bundler for production

## Deployment Strategy

### Build Process
- **Frontend**: Vite builds React app to `dist/public`
- **Backend**: ESBuild bundles server code to `dist/index.js`
- **Database**: Drizzle migrations applied via `db:push` command

### Environment Configuration
- **Development**: Uses `tsx` for TypeScript execution
- **Production**: Compiled JavaScript with Node.js
- **Database**: Requires `DATABASE_URL` environment variable

### File Structure
```
├── client/          # Frontend React application
├── server/          # Backend Express.js application
├── shared/          # Shared TypeScript definitions
├── migrations/      # Database migration files
└── dist/           # Built application files
```

The application is designed for easy deployment on platforms like Replit, with proper environment variable handling and build scripts for both development and production environments.