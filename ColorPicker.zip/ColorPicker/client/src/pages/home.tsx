import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Search, Users, MessageCircle, Bell, ThumbsUp, MessageSquare, Share2, Video, Image as ImageIcon, Smile, Rss, Tv, Store, Users2, Flag, Clock } from 'lucide-react';
import { useState } from "react";
import type { Post, User, FriendSuggestion, Comment } from "@shared/schema";

type PostWithAuthor = Post & { author: User };
type CommentWithAuthor = Comment & { author: User };

// Comments Section Component
function CommentsSection({ 
  postId, 
  currentUser, 
  newComment, 
  onCommentChange, 
  onSubmitComment, 
  isSubmitting 
}: {
  postId: number;
  currentUser: User | undefined;
  newComment: string;
  onCommentChange: (value: string) => void;
  onSubmitComment: () => void;
  isSubmitting: boolean;
}) {
  const { data: comments = [] } = useQuery<CommentWithAuthor[]>({
    queryKey: ["/api/posts", postId, "comments"],
    queryFn: async () => {
      const response = await fetch(`/api/posts/${postId}/comments`);
      return response.json();
    },
  });

  return (
    <div className="mt-3 pt-3 border-t border-gray-200">
      {/* Existing Comments */}
      {comments.map((comment) => (
        <div key={comment.id} className="flex items-start space-x-2 mb-3">
          <img 
            src={comment.author.avatarUrl || ""} 
            alt={comment.author.fullName} 
            className="w-8 h-8 rounded-full object-cover" 
          />
          <div className="flex-1 bg-gray-100 rounded-lg p-2">
            <div className="flex items-center space-x-2">
              <span className="font-semibold text-sm">{comment.author.fullName}</span>
              <span className="text-xs text-gray-500">
                {comment.createdAt ? new Date(comment.createdAt).toLocaleDateString() : "now"}
              </span>
            </div>
            <p className="text-sm">{comment.content}</p>
          </div>
        </div>
      ))}
      
      {/* New Comment Input */}
      <div className="flex items-center space-x-2 mt-3">
        <img 
          src={currentUser?.avatarUrl || ""} 
          alt={currentUser?.fullName || ""} 
          className="w-8 h-8 rounded-full object-cover" 
        />
        <div className="flex-1 flex items-center space-x-2">
          <input
            type="text"
            value={newComment}
            onChange={(e) => onCommentChange(e.target.value)}
            placeholder="Write a comment..."
            className="flex-1 bg-gray-100 rounded-full px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            onKeyPress={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                onSubmitComment();
              }
            }}
          />
          <button
            onClick={onSubmitComment}
            disabled={isSubmitting || !newComment.trim()}
            className="bg-blue-500 text-white px-3 py-2 rounded-full text-sm hover:bg-blue-600 disabled:opacity-50"
          >
            {isSubmitting ? "..." : "Post"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function Home() {
  const queryClient = useQueryClient();
  const [postContent, setPostContent] = useState("");
  const [showComments, setShowComments] = useState<{ [key: number]: boolean }>({});
  const [newComment, setNewComment] = useState<{ [key: number]: string }>({});

  // Queries
  const { data: posts = [], isLoading: postsLoading } = useQuery<PostWithAuthor[]>({
    queryKey: ["/api/posts"],
  });

  const { data: currentUser } = useQuery<User>({
    queryKey: ["/api/user/current"],
  });

  const { data: friendSuggestions = [] } = useQuery<FriendSuggestion[]>({
    queryKey: ["/api/friend-suggestions"],
  });

  // Mutations
  const createPostMutation = useMutation({
    mutationFn: async (content: string) => {
      const response = await apiRequest("POST", "/api/posts", { content });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      setPostContent("");
    },
  });

  const likePostMutation = useMutation({
    mutationFn: async (postId: number) => {
      const response = await apiRequest("POST", `/api/posts/${postId}/like`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
    },
  });

  const createCommentMutation = useMutation({
    mutationFn: async ({ postId, content }: { postId: number; content: string }) => {
      const response = await apiRequest("POST", `/api/posts/${postId}/comments`, { content });
      return response.json();
    },
    onSuccess: (_, { postId }) => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts", postId, "comments"] });
      setNewComment(prev => ({ ...prev, [postId]: "" }));
    },
  });

  const handleCreatePost = () => {
    if (postContent.trim()) {
      createPostMutation.mutate(postContent);
    }
  };

  const handleLikePost = (postId: number) => {
    likePostMutation.mutate(postId);
  };

  const toggleComments = (postId: number) => {
    setShowComments(prev => ({
      ...prev,
      [postId]: !prev[postId]
    }));
  };

  const handleCreateComment = (postId: number) => {
    const content = newComment[postId];
    if (content?.trim()) {
      createCommentMutation.mutate({ postId, content });
    }
  };

  const handleCommentChange = (postId: number, value: string) => {
    setNewComment(prev => ({
      ...prev,
      [postId]: value
    }));
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return "now";
    if (diffInHours < 24) return `${diffInHours}h ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
  };

  if (postsLoading) {
    return (
      <div className="min-h-screen bg-[#f0f2f5] flex items-center justify-center">
        <div className="text-lg">Loading...</div>
      </div>
    );
  }

  return (
    <div className="bg-[#f0f2f5] min-h-screen">
      {/* Header */}
      <header className="bg-[#3b5998] w-full p-2 flex items-center justify-between shadow-md fixed top-0 left-0 z-50">
        <div className="flex items-center">
          <h1 className="text-white text-2xl font-bold pr-4">idk bro i forgor :(</h1>
          <div className="relative">
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="text"
              placeholder="club penguin huh? yeah sure buddy"
              className="bg-white rounded-full pl-8 pr-4 py-1.5 text-sm focus:outline-none w-64"
            />
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 text-white font-semibold text-sm border-r border-blue-800 pr-4">
            <img 
              src={currentUser?.avatarUrl || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100"} 
              alt="User" 
              className="w-7 h-7 rounded-full object-cover" 
            />
            <span>bobby</span>
          </div>
          <div className="flex items-center space-x-4 text-white">
            <a href="#" className="hover:bg-blue-700 p-2 rounded">Home</a>
            <a href="#" className="hover:bg-blue-700 p-2 rounded relative">
              <Users size={20} />
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">2</span>
            </a>
            <a href="#" className="hover:bg-blue-700 p-2 rounded relative">
              <MessageCircle size={20} />
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">5</span>
            </a>
            <a href="#" className="hover:bg-blue-700 p-2 rounded relative">
              <Bell size={20} />
            </a>
          </div>
        </div>
      </header>

      <main className="flex pt-14">
        {/* Left Sidebar */}
        <aside className="w-1/5 p-4 pt-6 fixed h-full">
          <ul className="space-y-2">
            <li>
              <a href="#" className="flex items-center space-x-3 p-2 rounded-md hover:bg-gray-200">
                <img 
                  src={currentUser?.avatarUrl || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100"} 
                  alt="User" 
                  className="w-7 h-7 rounded-full object-cover" 
                />
                <span className="font-semibold">{currentUser?.fullName || "wait who am i again"}</span>
              </a>
            </li>
            <li><a href="#" className="flex items-center space-x-3 p-2 rounded-md hover:bg-gray-200"><Rss size={24} className="text-blue-500" /><span className="font-semibold">News Feed</span></a></li>
            <li><a href="#" className="flex items-center space-x-3 p-2 rounded-md hover:bg-gray-200"><MessageCircle size={24} className="text-blue-500" /><span className="font-semibold">Messenger</span></a></li>
            <li><a href="#" className="flex items-center space-x-3 p-2 rounded-md hover:bg-gray-200"><Tv size={24} className="text-blue-500" /><span className="font-semibold">Watch</span></a></li>
            <li><a href="#" className="flex items-center space-x-3 p-2 rounded-md hover:bg-gray-200"><Store size={24} className="text-green-500" /><span className="font-semibold">Marketplace</span></a></li>
          </ul>
          <h3 className="mt-4 text-gray-500 font-semibold text-sm">Shortcuts</h3>
          <ul className="space-y-2 mt-2">
            <li><a href="#" className="flex items-center space-x-3 p-2 rounded-md hover:bg-gray-200"><Users2 size={24} className="text-purple-500" /><span className="font-semibold">Design Group</span></a></li>
            <li><a href="#" className="flex items-center space-x-3 p-2 rounded-md hover:bg-gray-200"><Flag size={24} className="text-orange-500" /><span className="font-semibold">React Developers</span></a></li>
          </ul>
          <h3 className="mt-4 text-gray-500 font-semibold text-sm">Explore</h3>
          <ul className="space-y-2 mt-2">
            <li><a href="#" className="flex items-center space-x-3 p-2 rounded-md hover:bg-gray-200"><Clock size={24} className="text-gray-600" /><span className="font-semibold">Memories</span></a></li>
          </ul>
        </aside>

        {/* Main Feed */}
        <div className="w-full px-4" style={{ marginLeft: '20%', marginRight: '25%' }}>
          <div className="max-w-xl mx-auto py-4 space-y-4">
            
            {/* Create Post */}
            <div className="bg-white p-4 rounded-lg shadow-md border border-gray-300">
              <div className="flex space-x-3 border-b pb-3">
                <img 
                  src={currentUser?.avatarUrl || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100"} 
                  alt="User" 
                  className="w-10 h-10 rounded-full object-cover" 
                />
                <textarea 
                  placeholder={`Wait what was I going to post...?`}
                  className="w-full border-none focus:ring-0 resize-none text-lg" 
                  rows={2}
                  value={postContent}
                  onChange={(e) => setPostContent(e.target.value)}
                />
              </div>
              <div className="flex justify-between pt-3">
                <button className="flex items-center space-x-2 text-gray-600 hover:bg-gray-100 p-2 rounded-lg font-semibold">
                  <Video className="text-red-500" />
                  <span>Live Video</span>
                </button>
                <button className="flex items-center space-x-2 text-gray-600 hover:bg-gray-100 p-2 rounded-lg font-semibold">
                  <ImageIcon className="text-green-500" />
                  <span>Photo/Video</span>
                </button>
                <button className="flex items-center space-x-2 text-gray-600 hover:bg-gray-100 p-2 rounded-lg font-semibold">
                  <Smile className="text-yellow-500" />
                  <span>Feeling/Activity</span>
                </button>
              </div>
              {postContent.trim() && (
                <div className="mt-3 pt-3 border-t">
                  <button 
                    onClick={handleCreatePost}
                    disabled={createPostMutation.isPending}
                    className="w-full bg-[#3b5998] text-white py-2 rounded-lg font-semibold hover:bg-blue-700 disabled:opacity-50"
                  >
                    {createPostMutation.isPending ? "Posting..." : "Post"}
                  </button>
                </div>
              )}
            </div>

            {/* Posts */}
            {posts.map((post) => (
              <div key={post.id} className="bg-white p-4 rounded-lg shadow-md border border-gray-300">
                <div className="flex items-center space-x-3 mb-3">
                  <img src={post.author.avatarUrl || ""} alt={post.author.fullName} className="w-10 h-10 rounded-full object-cover" />
                  <div>
                    <p className="font-bold text-sm">
                      <a href="#" className="hover:underline">{post.author.fullName}</a>
                    </p>
                    <p className="text-xs text-gray-500">{post.createdAt ? formatTimeAgo(new Date(post.createdAt)) : "now"}</p>
                  </div>
                </div>
                <p className="mb-3">{post.content}</p>
                {post.imageUrl && <img src={post.imageUrl} alt="Post content" className="w-full rounded-lg mb-3" />}
                <div className="flex justify-between text-gray-500 text-sm mb-2">
                  <span>
                    {post.id === 2 ? 
                      "how many likes were there?" : 
                      <div className="flex items-center space-x-1">
                        <div className="flex -space-x-1">
                          <div className="w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center text-white text-xs font-bold">
                            👍
                          </div>
                          <div className="w-5 h-5 bg-red-500 rounded-full flex items-center justify-center text-white text-xs">
                            ❤️
                          </div>
                        </div>
                        <span className="ml-1">{post.likes}</span>
                      </div>
                    }
                  </span>
                  <span>{post.comments} Comments</span>
                </div>
                <div className="border-t border-b border-gray-200 flex justify-around py-1">
                  <button 
                    onClick={() => handleLikePost(post.id)}
                    disabled={likePostMutation.isPending}
                    className="flex items-center justify-center w-full space-x-2 text-gray-600 hover:bg-gray-100 p-2 rounded-lg font-semibold"
                  >
                    <ThumbsUp size={20} />
                    <span>Like</span>
                  </button>
                  <button 
                    onClick={() => toggleComments(post.id)}
                    className="flex items-center justify-center w-full space-x-2 text-gray-600 hover:bg-gray-100 p-2 rounded-lg font-semibold"
                  >
                    <MessageSquare size={20} />
                    <span>Comment</span>
                  </button>
                  <button className="flex items-center justify-center w-full space-x-2 text-gray-600 hover:bg-gray-100 p-2 rounded-lg font-semibold">
                    <Share2 size={20} />
                    <span>Share</span>
                  </button>
                </div>
                
                {/* Comments Section */}
                {showComments[post.id] && (
                  <CommentsSection 
                    postId={post.id} 
                    currentUser={currentUser}
                    newComment={newComment[post.id] || ""}
                    onCommentChange={(value) => handleCommentChange(post.id, value)}
                    onSubmitComment={() => handleCreateComment(post.id)}
                    isSubmitting={createCommentMutation.isPending}
                  />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Right Sidebar */}
        <aside className="w-1/4 p-4 pt-6 fixed right-0 h-full overflow-y-auto">
          <div className="bg-white p-3 rounded-lg shadow-md border border-gray-300">
            <h3 className="font-bold text-gray-800 mb-2">Sponsored</h3>
            <div className="text-center">
              <h4 className="font-bold text-purple-600 mb-2">✨ FETUS DELETUS ✨ The Ultimate Solution!</h4>
              <img src="/attached_assets/download_1752286689400.webp" alt="Ad" className="w-full rounded-lg mb-2" />
              <a href="#" className="block bg-purple-500 text-white font-bold py-2 px-4 rounded hover:bg-purple-600 text-sm mb-1">
                ORDER NOW! Limited Time!
              </a>
              <p className="text-xs text-gray-500">fetus-deletus-magic.totally-legit.com</p>
            </div>
          </div>
          <div className="bg-white p-3 rounded-lg shadow-md border border-gray-300 mt-4">
            <h3 className="font-bold text-red-600 mb-2">🔥 AMAZING! 57 Hot Single Moms Within 10km Are Looking For You! 🔥</h3>
            <div className="text-center">
              <img src="/attached_assets/infphoto1128097_-_1_1752286315330.webp" alt="Ad" className="w-full rounded-lg mb-2" />
              <a href="#" className="block bg-red-500 text-white font-bold py-2 px-4 rounded hover:bg-red-600 text-sm">
                CLICK HERE NOW! Don't Miss Out!
              </a>
              <p className="text-xs text-gray-500 mt-1">hotsinglemoms.totally-real-site.com</p>
            </div>
          </div>
        </aside>
      </main>
    </div>
  );
}
