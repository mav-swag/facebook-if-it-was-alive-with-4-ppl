import { users, posts, comments, friendSuggestions, type User, type InsertUser, type Post, type InsertPost, type Comment, type InsertComment, type FriendSuggestion, type InsertFriendSuggestion } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getPosts(): Promise<(Post & { author: User })[]>;
  getPost(id: number): Promise<(Post & { author: User }) | undefined>;
  createPost(post: InsertPost & { authorId: number }): Promise<Post>;
  likePost(id: number): Promise<Post | undefined>;
  
  getComments(postId: number): Promise<(Comment & { author: User })[]>;
  createComment(comment: InsertComment): Promise<Comment>;
  
  getFriendSuggestions(): Promise<FriendSuggestion[]>;
  createFriendSuggestion(suggestion: InsertFriendSuggestion): Promise<FriendSuggestion>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private posts: Map<number, Post>;
  private comments: Map<number, Comment>;
  private friendSuggestions: Map<number, FriendSuggestion>;
  private currentUserId: number;
  private currentPostId: number;
  private currentCommentId: number;
  private currentSuggestionId: number;

  constructor() {
    this.users = new Map();
    this.posts = new Map();
    this.comments = new Map();
    this.friendSuggestions = new Map();
    this.currentUserId = 1;
    this.currentPostId = 1;
    this.currentCommentId = 1;
    this.currentSuggestionId = 1;
    
    // Initialize with some sample data
    this.initializeData();
  }

  private async initializeData() {
    // Create sample users
    const chris = await this.createUser({
      username: "chris",
      password: "password",
      fullName: "lost id idk where i from,idk who am or from when earth",
      avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100"
    });

    const john = await this.createUser({
      username: "john",
      password: "password",
      fullName: "kumalala",
      avatarUrl: "/attached_assets/Kumalala_2_1752285214847.webp"
    });

    const bosnov = await this.createUser({
      username: "bosnov",
      password: "password",
      fullName: "bosnov",
      avatarUrl: "/attached_assets/images (1)_1752285531513.webp"
    });

    const jane = await this.createUser({
      username: "jane",
      password: "password",
      fullName: "Ye",
      avatarUrl: "/attached_assets/5f3eb1be4433655d27814c71aa388ed0_1752286072110.webp"
    });

    const techUpdates = await this.createUser({
      username: "techupdates",
      password: "password",
      fullName: "gabe itch",
      avatarUrl: "/attached_assets/cropped-1002095730-photo-u1_1752284078882.webp"
    });

    // Create sample posts
    await this.createPost({
      authorId: bosnov.id,
      content: "did anyone see my brother bilo?he looked like this",
      imageUrl: "/attached_assets/bosnov-my-brother-bilo_1752285747402.webp"
    });

    await this.createPost({
      authorId: jane.id,
      content: "yo guess what i just read with my cousin",
      imageUrl: "/attached_assets/5f3eb1be4433655d27814c71aa388ed0_1752286072110.webp"
    });

    await this.createPost({
      authorId: techUpdates.id,
      content: "i got j*b :(((((",
      imageUrl: "/attached_assets/i-got-a-new-work-v0-dzr7jyoy23nc1_1752283468578.webp"
    });

    // Set like counts
    this.posts.get(1)!.likes = 128;
    this.posts.get(1)!.comments = 3;
    this.posts.get(2)!.likes = 256;
    this.posts.get(2)!.comments = 3;
    this.posts.get(3)!.likes = 67;
    this.posts.get(3)!.comments = 3;

    // Add comments to all posts
    // Comments on bosnov's post about his brother bilo
    await this.createComment({
      postId: 1,
      authorId: john.id,
      content: "broo i think i saw him at walmart yesterday"
    });
    
    await this.createComment({
      postId: 1,
      authorId: jane.id,
      content: "bilo gone missing again? 😭"
    });
    
    await this.createComment({
      postId: 1,
      authorId: techUpdates.id,
      content: "maybe check the park he always goes there"
    });

    // Comments on Ye's post
    await this.createComment({
      postId: 2,
      authorId: bosnov.id,
      content: "what did u read tho"
    });
    
    await this.createComment({
      postId: 2,
      authorId: john.id,
      content: "bro share the tea ☕"
    });
    
    await this.createComment({
      postId: 2,
      authorId: techUpdates.id,
      content: "was it good or nah"
    });

    // Comments on gabe's job post
    await this.createComment({
      postId: 3,
      authorId: john.id,
      content: "sybau gooner 🥀💔"
    });
    
    await this.createComment({
      postId: 3,
      authorId: bosnov.id,
      content: "congrats man!! what job is it"
    });
    
    await this.createComment({
      postId: 3,
      authorId: jane.id,
      content: "yooo that's fire 🔥🔥"
    });

    // Create friend suggestions
    await this.createFriendSuggestion({
      name: "wait do i know this person",
      avatarUrl: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
      mutualFriends: 12
    });

    await this.createFriendSuggestion({
      name: "wait who invited this guy",
      avatarUrl: "https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
      mutualFriends: 5
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async getPosts(): Promise<(Post & { author: User })[]> {
    const posts = Array.from(this.posts.values());
    const postsWithAuthors = await Promise.all(
      posts.map(async (post) => {
        const author = await this.getUser(post.authorId);
        return { ...post, author: author! };
      })
    );
    return postsWithAuthors.sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime());
  }

  async getPost(id: number): Promise<(Post & { author: User }) | undefined> {
    const post = this.posts.get(id);
    if (!post) return undefined;
    
    const author = await this.getUser(post.authorId);
    if (!author) return undefined;
    
    return { ...post, author };
  }

  async createPost(post: InsertPost & { authorId: number }): Promise<Post> {
    const id = this.currentPostId++;
    const newPost: Post = {
      ...post,
      id,
      likes: 0,
      comments: 0,
      createdAt: new Date()
    };
    this.posts.set(id, newPost);
    return newPost;
  }

  async likePost(id: number): Promise<Post | undefined> {
    const post = this.posts.get(id);
    if (!post) return undefined;
    
    post.likes = (post.likes || 0) + 1;
    this.posts.set(id, post);
    return post;
  }

  async getComments(postId: number): Promise<(Comment & { author: User })[]> {
    const comments = Array.from(this.comments.values())
      .filter(comment => comment.postId === postId)
      .sort((a, b) => a.createdAt!.getTime() - b.createdAt!.getTime());
    
    const commentsWithAuthors = await Promise.all(
      comments.map(async (comment) => {
        const author = await this.getUser(comment.authorId);
        return { ...comment, author: author! };
      })
    );
    
    return commentsWithAuthors;
  }

  async createComment(comment: InsertComment): Promise<Comment> {
    const id = this.currentCommentId++;
    const newComment: Comment = {
      ...comment,
      id,
      createdAt: new Date()
    };
    this.comments.set(id, newComment);
    
    // Update comment count on post
    const post = this.posts.get(comment.postId);
    if (post) {
      post.comments = (post.comments || 0) + 1;
      this.posts.set(comment.postId, post);
    }
    
    return newComment;
  }

  async getFriendSuggestions(): Promise<FriendSuggestion[]> {
    return Array.from(this.friendSuggestions.values());
  }

  async createFriendSuggestion(suggestion: InsertFriendSuggestion): Promise<FriendSuggestion> {
    const id = this.currentSuggestionId++;
    const newSuggestion: FriendSuggestion = { ...suggestion, id };
    this.friendSuggestions.set(id, newSuggestion);
    return newSuggestion;
  }
}

export const storage = new MemStorage();
