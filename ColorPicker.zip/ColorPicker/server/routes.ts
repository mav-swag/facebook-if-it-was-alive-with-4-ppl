import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertPostSchema, insertCommentSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all posts
  app.get("/api/posts", async (req, res) => {
    try {
      const posts = await storage.getPosts();
      res.json(posts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch posts" });
    }
  });

  // Create a new post
  app.post("/api/posts", async (req, res) => {
    try {
      const validatedPost = insertPostSchema.parse(req.body);
      // For now, use a default author ID (Chris - user ID 1)
      const post = await storage.createPost({ ...validatedPost, authorId: 1 });
      const postWithAuthor = await storage.getPost(post.id);
      res.json(postWithAuthor);
    } catch (error) {
      res.status(400).json({ error: "Failed to create post" });
    }
  });

  // Like a post
  app.post("/api/posts/:id/like", async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      const post = await storage.likePost(postId);
      if (!post) {
        return res.status(404).json({ error: "Post not found" });
      }
      res.json(post);
    } catch (error) {
      res.status(500).json({ error: "Failed to like post" });
    }
  });

  // Get comments for a post
  app.get("/api/posts/:id/comments", async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      const comments = await storage.getComments(postId);
      res.json(comments);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch comments" });
    }
  });

  // Create a comment
  app.post("/api/posts/:id/comments", async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      const validatedComment = insertCommentSchema.parse(req.body);
      const comment = await storage.createComment({ ...validatedComment, postId, authorId: 1 });
      const commentWithAuthor = await storage.getComments(postId);
      res.json(commentWithAuthor);
    } catch (error) {
      res.status(400).json({ error: "Failed to create comment" });
    }
  });

  // Get friend suggestions
  app.get("/api/friend-suggestions", async (req, res) => {
    try {
      const suggestions = await storage.getFriendSuggestions();
      res.json(suggestions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch friend suggestions" });
    }
  });

  // Get current user (for now, return Chris)
  app.get("/api/user/current", async (req, res) => {
    try {
      const user = await storage.getUser(1); // Chris
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
